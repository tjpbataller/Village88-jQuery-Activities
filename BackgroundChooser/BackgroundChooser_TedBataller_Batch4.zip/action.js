$(document).ready(function(){
    $('div#main_box').click(function(){
        $(this).css('background-image','unset');
    });
    $('img.mini_boxes').click(function(event){
        event.stopPropagation();
        $('div#main_box').css('background-image',"url('" + $(this).attr("src") + "')");
    });
});